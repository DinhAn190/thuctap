import numpy as np
from scipy.spatial import cKDTree


def idw_interpolation(
    lons,
    lats,
    values,
    grid_lon,
    grid_lat,
    power=2,
    radius=None,
    k=12,
    min_neighbors=3
):

    """
    IDW interpolation chuẩn GIS

    Parameters
    ----------
    lons, lats : tọa độ trạm
    values : giá trị AQI
    grid_lon, grid_lat : meshgrid raster
    power : hệ số IDW
    radius : bán kính tìm kiếm (degree)
    k : số neighbor tối đa
    min_neighbors : số neighbor tối thiểu
    """

    # tạo array điểm trạm
    points = np.column_stack((lons, lats))

    # tạo KDTree
    tree = cKDTree(points)

    # flatten grid
    grid_points = np.column_stack((grid_lon.ravel(), grid_lat.ravel()))

    # giới hạn k
    k = min(k, len(values))

    # query neighbor
    dist, idx = tree.query(grid_points, k=k)

    # reshape nếu k=1
    if k == 1:
        dist = dist[:, np.newaxis]
        idx = idx[:, np.newaxis]

    # fix index overflow
    idx = np.clip(idx, 0, len(values) - 1)

    # tạo raster output
    interpolated = np.full(len(grid_points), np.nan)

    for i in range(len(grid_points)):

        d = dist[i]
        idn = idx[i]

        # loại bỏ distance vô hạn
        valid = np.isfinite(d)

        d = d[valid]
        idn = idn[valid]

        if len(d) < min_neighbors:
            continue

        # search radius
        if radius is not None:

            mask = d <= radius

            d = d[mask]
            idn = idn[mask]

            if len(d) < min_neighbors:
                continue

        # tránh chia 0
        d[d == 0] = 1e-12

        # tính weight
        weights = 1 / (d ** power)

        weights = weights / weights.sum()

        # tính giá trị nội suy
        interpolated[i] = np.sum(weights * values[idn])

    # reshape raster
    grid = interpolated.reshape(grid_lon.shape)

    # đảo raster chuẩn GIS
    grid = np.flipud(grid)

    return grid
import requests

AQICN_TOKEN = "YOUR_AQICN_API_KEY"

VN_BOUNDS = "8,102,24,110"

def fetch_all_vn_stations():
    url = f"https://api.waqi.info/map/bounds/?latlng={VN_BOUNDS}&token={AQICN_TOKEN}"
    res = requests.get(url, timeout=15)
    data = res.json()

    if data.get("status") != "ok":
        return []

    return data["data"]

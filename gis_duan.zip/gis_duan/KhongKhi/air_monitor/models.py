from django.db import models

class AirQuality(models.Model):
    station_uid = models.IntegerField(unique=True)
    city = models.CharField(max_length=255)
    aqi = models.IntegerField(null=True) 
    pm25 = models.FloatField(null=True)
    pm10 = models.FloatField(null=True)

    temperature = models.FloatField(null=True)
    humidity = models.FloatField(null=True)
    latitude = models.FloatField()
    longitude = models.FloatField()
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.city} - AQI: {self.aqi}"

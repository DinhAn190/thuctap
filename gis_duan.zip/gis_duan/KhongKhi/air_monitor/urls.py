from django.urls import path
from . import views

urlpatterns = [

    path('', views.air_quality_map, name='home'),

    # API cho map
    path('api/aqi-stations/', views.api_aqi_stations, name='api_aqi_stations'),

    # lấy dữ liệu AQI toàn Việt Nam
    path('fetch-vn-aqi/', views.fetch_vn_aqi, name='fetch_vn_aqi'), 


    # Nội suy
    path("api/aqi-interpolation/", views.api_aqi_interpolation), 

    path("stations/",views.stations,name="stations"), 

    # dashboard thống kê
    path("dashboard/", views.dashboard, name="dashboard"),

]
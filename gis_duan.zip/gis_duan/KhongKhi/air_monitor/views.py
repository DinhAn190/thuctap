from django.shortcuts import render
from django.http import JsonResponse
from .models import AirQuality
from services.interpolation import idw_interpolation
import requests 
import numpy as np


# TOKEN AQICN
WAQI_TOKEN = "76c98db3ebca951d2a62dea65a30665da91fca36"

# Bounding box Việt Nam
VN_BOUNDS = "8,102,23.5,109.5"


def fetch_vn_aqi(request):

    url = f"https://api.waqi.info/map/bounds/?latlng={VN_BOUNDS}&token={WAQI_TOKEN}"

    response = requests.get(url, timeout=20)
    data = response.json()

    if data.get("status") != "ok":
        return JsonResponse({"error": "API error"}, status=500)

    stations = data["data"]
    count = 0

    for s in stations:

        uid = s.get("uid")
        name = s.get("station", {}).get("name", "")
        lat = s.get("lat")
        lon = s.get("lon")

        try:
            aqi = int(s.get("aqi"))
        except:
            continue

        # Lấy dữ liệu chi tiết trạm
        detail_url = f"https://api.waqi.info/feed/@{uid}/?token={WAQI_TOKEN}"
        detail = requests.get(detail_url).json()

        iaqi = detail.get("data", {}).get("iaqi", {})

        pm25 = iaqi.get("pm25", {}).get("v")
        pm10 = iaqi.get("pm10", {}).get("v")
        temp = iaqi.get("t", {}).get("v")
        humidity = iaqi.get("h", {}).get("v")

        AirQuality.objects.update_or_create(
            station_uid=uid,
            defaults={
                "city": name,
                "aqi": aqi,
                "pm25": pm25,
                "pm10": pm10,
                "temperature": temp,
                "humidity": humidity,
                "latitude": lat,
                "longitude": lon,
            }
        )

        count += 1

    return JsonResponse({
        "status": "success",
        "stations_saved": count
    })


def api_aqi_stations(request):

    stations = AirQuality.objects.exclude(
    latitude__isnull=True,
    longitude__isnull=True,
    aqi__isnull=True
    ).values(
    "city",
    "aqi",
    "pm25",
    "pm10",
    "temperature",
    "humidity",
    "latitude",
    "longitude"
    )

    return JsonResponse(list(stations), safe=False)
    

def api_aqi_interpolation(request):

    stations = AirQuality.objects.exclude(
        latitude__isnull=True,
        longitude__isnull=True,
        aqi__isnull=True
    )

    lats = []
    lons = []
    values = []

    for s in stations:

        try:
            lats.append(float(s.latitude))
            lons.append(float(s.longitude))
            values.append(float(s.aqi))
        except:
            continue

    if len(values) < 3:
        return JsonResponse({"error": "not enough stations"})

    lats = np.array(lats)
    lons = np.array(lons)
    values = np.array(values)

    lat_min, lat_max = 8, 24
    lon_min, lon_max = 102, 110.5

    grid_res = 0.05

    grid_lat = np.arange(lat_min, lat_max, grid_res)
    grid_lon = np.arange(lon_min, lon_max, grid_res)

    grid_lon, grid_lat = np.meshgrid(grid_lon, grid_lat)

    grid = idw_interpolation(lons, lats, values, grid_lon, grid_lat)

    result = []

    for i in range(grid.shape[0]):
        for j in range(grid.shape[1]):

            result.append({
                "lat": float(grid_lat[i][j]),
                "lon": float(grid_lon[i][j]),
                "aqi": float(grid[i][j])
            })

    return JsonResponse(result, safe=False)
def air_quality_map(request):
    return render(request, "map.html") 

def stations(request):
    return render(request,"air_monitor/stations.html")

def dashboard(request):
    return render(request, "air_monitor/dashboard.html")
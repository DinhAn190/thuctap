import json
from channels.generic.websocket import AsyncWebsocketConsumer
from .models import AirQuality

class AQIConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.accept()
    
    async def disconnect(self, close_code):
        pass
    
    async def send_aqi_data(self):
        latest_data = AirQuality.objects.all().order_by('-timestamp')[:10]
        data = [{"city": d.city, "aqi": d.aqi, "timestamp": d.timestamp.strftime("%Y-%m-%d %H:%M:%S")} for d in latest_data]
        await self.send(text_data=json.dumps({"air_quality": data}))

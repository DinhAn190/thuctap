from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
import openmeteo_requests
import requests_cache
from retry_requests import retry
import random
import joblib
import numpy as np
from .models import WeatherData, AHPWeights, AlternativeScore
from datetime import datetime

# =====================
# HOME
# =====================
def home(request):
    return redirect('login')

# =====================
# LOGIN - ĐÃ SỬA
# =====================
def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        if not username or not password:
            messages.error(request, "Vui lòng nhập đầy đủ thông tin")
            return render(request, 'login.html')
        
        # Xác thực user
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            messages.success(request, f"Chào mừng {username} trở lại!")
            return redirect('dashboard')
        else:
            messages.error(request, "Sai tài khoản hoặc mật khẩu")
            return render(request, 'login.html')
    
    return render(request, 'login.html')

# =====================
# REGISTER - ĐÃ SỬA
# =====================
def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        
        # Validate
        if not username or not email or not password:
            messages.error(request, "Vui lòng điền đầy đủ thông tin")
            return render(request, 'register.html')
        
        if password != confirm_password:
            messages.error(request, "Mật khẩu xác nhận không khớp")
            return render(request, 'register.html')
        
        if len(password) < 6:
            messages.error(request, "Mật khẩu phải có ít nhất 6 ký tự")
            return render(request, 'register.html')
        
        # Kiểm tra username tồn tại
        if User.objects.filter(username=username).exists():
            messages.error(request, "Tên đăng nhập đã tồn tại")
            return render(request, 'register.html')
        
        # Kiểm tra email tồn tại
        if User.objects.filter(email=email).exists():
            messages.error(request, "Email đã được sử dụng")
            return render(request, 'register.html')
        
        try:
            # Tạo user mới
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password
            )
            user.save()
            
            messages.success(request, "Đăng ký thành công! Hãy đăng nhập.")
            return redirect('login')
            
        except Exception as e:
            messages.error(request, f"Có lỗi xảy ra: {str(e)}")
            return render(request, 'register.html')
    
    return render(request, 'register.html')

# =====================
# LOGOUT
# =====================
def user_logout(request):
    logout(request)
    messages.info(request, "Bạn đã đăng xuất thành công")
    return redirect('login')

# =====================
# DASHBOARD
# =====================
@login_required
def dashboard(request):
    cache_session = requests_cache.CachedSession('.cache', expire_after=15)
    retry_session = retry(cache_session, retries=5, backoff_factor=0.2)
    openmeteo = openmeteo_requests.Client(session=retry_session)

    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": 12.3977,
        "longitude": 108.2181,
        "current": [
            "temperature_2m",
            "relative_humidity_2m",
            "rain",
            "wind_speed_10m",
            "shortwave_radiation"
        ],
        "hourly": [
            "temperature_2m",
            "et0_fao_evapotranspiration",
            "soil_moisture_0_to_1cm"
        ],
        "timezone": "Asia/Bangkok"
    }

    responses = openmeteo.weather_api(url, params=params)
    response = responses[0]
    current = response.Current()

    temperature = round(current.Variables(0).Value(), 2)
    humidity = round(current.Variables(1).Value(), 2)
    rain = round(current.Variables(2).Value(), 2)
    wind = round(current.Variables(3).Value(), 2)
    radiation = round(current.Variables(4).Value(), 2)

    hourly = response.Hourly()
    try:
        eto = round(float(hourly.Variables(1).ValuesAsNumpy()[0]), 2)
    except:
        eto = 0

    try:
        soil_moisture = round(float(hourly.Variables(2).ValuesAsNumpy()[0]), 3)
    except:
        soil_moisture = 0

    score, irrigation_status = ai_predict(
        soil_moisture, rain, eto, temperature, humidity, radiation
    )

    context = {
        "temperature": temperature,
        "humidity": humidity,
        "rain": rain,
        "wind": wind,
        "radiation": radiation,
        "soil_moisture": soil_moisture,
        "eto": eto,
        "irrigation_status": irrigation_status,
        "ai_score": score, 

            # 👇 thêm cái này
    "labels": ['10h','11h','12h','13h','14h'],
    "values": [30,31,32,31,30],
    "soil_labels": ['10h','11h','12h','13h','14h'],
    "soil_values": [0.2,0.25,0.3,0.28,0.27],
        "current_time": datetime.now().strftime("%H:%M:%S"),
        "current_date": datetime.now().strftime("%d/%m/%Y"),
    }

    return render(request, "dashboard.html", context)

# =====================
# AI MODEL
# =====================
model = joblib.load("irrigation_ai.pkl")

def ai_predict(soil, rain, eto, temp, humidity, radiation):
    X = np.array([[soil, rain, eto, temp, humidity, radiation]])
    pred = model.predict(X)[0]
    proba = model.predict_proba(X)[0]
    score = round(float(max(proba)) * 10, 2)

    if pred == "high":
        result = "💧 Tưới nhiều"
    elif pred == "medium":
        result = "💧 Tưới vừa"
    elif pred == "low":
        result = "💧 Tưới ít"
    else:
        result = "❌ Không tưới"

    return score, result

# =====================
# Realtime weather API
# =====================
def realtime_data(request):
    cache_session = requests_cache.CachedSession('.cache', expire_after=15)
    retry_session = retry(cache_session, retries=5, backoff_factor=0.2)
    openmeteo = openmeteo_requests.Client(session=retry_session)

    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": 12.3977,
        "longitude": 108.2181,
        "current": [
            "temperature_2m",
            "relative_humidity_2m",
            "rain",
            "wind_speed_10m",
            "shortwave_radiation"
        ]
    }

    responses = openmeteo.weather_api(url, params=params)
    response = responses[0]
    current = response.Current()

    data = {
        "temperature": round(current.Variables(0).Value(), 2),
        "humidity": round(current.Variables(1).Value(), 2),
        "rain": round(current.Variables(2).Value(), 2),
        "wind": round(current.Variables(3).Value(), 2),
        "radiation": round(current.Variables(4).Value(), 2),
    }

    return JsonResponse(data)

# =====================
# AHP irrigation tool
# =====================
@csrf_exempt
def calculate_irrigation(request):
    if request.method == "POST":
        soil = float(request.POST.get("soil", 0))
        rain = float(request.POST.get("rain", 0))
        eto = float(request.POST.get("eto", 0))
        temp = float(request.POST.get("temp", 0))
        humidity = float(request.POST.get("humidity", 0))
        radiation = float(request.POST.get("radiation", 0))

        score = (
            soil * 0.28 +
            rain * 0.11 +
            eto * 0.25 +
            temp * 0.13 +
            humidity * 0.07 +
            radiation * 0.15
        )

        if score < 20:
            result = "💧 Tưới nhiều"
            advice = "Độ ẩm đất thấp, cần tưới nhiều nước để duy trì cây trồng"
        elif score < 40:
            result = "💧 Tưới vừa"
            advice = "Độ ẩm đất ở mức trung bình, tưới vừa phải"
        elif score < 60:
            result = "💧 Tưới ít"
            advice = "Độ ẩm đất khá cao, chỉ cần tưới ít"
        else:
            result = "❌ Không tưới"
            advice = "Độ ẩm đất tốt, không cần tưới"

        return JsonResponse({
            "score": round(score, 2),
            "result": result,
            "advice": advice
        })

    return JsonResponse({"error": "Invalid request"})

# =====================
# MAP
# =====================
def map_view(request):
    return render(request, "map.html")

def map_status(request):
    soil = round(random.uniform(0.2, 0.6), 3)
    rain = round(random.uniform(0, 5), 2)
    temp = round(random.uniform(25, 33), 2)
    humidity = round(random.uniform(50, 80), 2)
    eto = round(random.uniform(2, 5), 2)
    radiation = round(random.uniform(180, 260), 2)

    if soil < 0.3:
        status = "Tưới nhiều"
        color = "red"
        icon = "💧💧💧"
    elif soil < 0.4:
        status = "Tưới vừa"
        color = "orange"
        icon = "💧💧"
    elif soil < 0.5:
        status = "Tưới ít"
        color = "yellow"
        icon = "💧"
    else:
        status = "Không tưới"
        color = "green"
        icon = "✅"

    return JsonResponse({
        "soil": soil,
        "rain": rain,
        "temp": temp,
        "humidity": humidity,
        "eto": eto,
        "radiation": radiation,
        "status": status,
        "color": color,
        "icon": icon
    })

# =====================
# SENSOR PAGE
# =====================
def sensor_page(request):
    return render(request, "sensor.html")

def sensor_data(request):
    data = {
        "temperature": round(random.uniform(24, 30), 2),
        "humidity": round(random.uniform(55, 75), 2),
        "soil": round(random.uniform(0.15, 0.45), 3),
        "rain": round(random.uniform(0, 5), 2),
        "radiation": round(random.uniform(180, 250), 2)
    }

    alert = ""
    alert_level = "normal"
    
    if data["soil"] < 0.18:
        alert = "⚠️ CẢNH BÁO: Đất quá khô! Cần tưới ngay!"
        alert_level = "danger"
    elif data["soil"] > 0.45:
        alert = "⚠️ CẢNH BÁO: Đất quá ẩm! Nguy cơ úng rễ!"
        alert_level = "warning"
    elif data["temperature"] > 35:
        alert = "⚠️ Nhiệt độ quá cao! Cần che chắn cho cây!"
        alert_level = "warning"
    elif data["humidity"] < 40:
        alert = "⚠️ Độ ẩm thấp! Cần tăng độ ẩm không khí!"
        alert_level = "info"

    return JsonResponse({
        "data": data,
        "alert": alert,
        "alert_level": alert_level
    })

# =====================
# OTHER PAGES
# =====================
def irrigation_page(request):
    return render(request, "irrigation_control.html")

def about_page(request):
    return render(request, "about.html")

def ahp_page(request):
    return render(request, "ahp.html")

def get_weather(request):
    data = WeatherData.objects.all().order_by('-time')[:50]
    result = []
    for d in data:
        result.append({
            "time": d.time.strftime("%Y-%m-%d %H:%M:%S"),
            "temperature": d.temperature,
            "humidity": d.humidity,
            "rain": d.rain,
            "radiation": d.radiation
        })
    return JsonResponse(result, safe=False)

def ahp_view(request):
    weights = AHPWeights.objects.all().order_by('criterion')
    scores = AlternativeScore.objects.all()
    
    alternatives = ['PA1', 'PA2', 'PA3', 'PA4']
    total_scores = {}
    
    for alt in alternatives:
        total = 0
        for w in weights:
            score = scores.get(alternative=alt, criterion=w.criterion).score
            total += w.weight * score
        total_scores[alt] = round(total * 100, 2)
    
    ranked = sorted(total_scores.items(), key=lambda x: x[1], reverse=True)
    
    context = {
        'weights': weights,
        'scores': scores,
        'total_scores': total_scores,
        'ranked': ranked,
    }
    
    return render(request, 'ahp.html', context)
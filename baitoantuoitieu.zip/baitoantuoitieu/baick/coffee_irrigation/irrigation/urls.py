from django.urls import path
from . import views 

urlpatterns = [ 
    path('', views.home, name='home'),
    path('map/', views.map_view, name='map'),
    path('calculate/', views.calculate_irrigation, name='calculate'),
    path('realtime/', views.realtime_data, name='realtime'),
    path('map_status/', views.map_status, name='map_status'),
    path('sensor/', views.sensor_page, name='sensor'),
    path('sensor_data/', views.sensor_data, name='sensor_data'),
    path('irrigation/', views.irrigation_page, name='irrigation'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('ahp/', views.ahp_page, name='ahp'),
    path('api/weather/', views.get_weather, name='get_weather'),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
]
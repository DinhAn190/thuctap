"""
URL configuration for coffee_irrigation project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from irrigation import views
from django.contrib import admin
from django.urls import path,include
from django.views.generic import TemplateView
urlpatterns = [

path('admin/', admin.site.urls),

path('',include('irrigation.urls')),
path('', TemplateView.as_view(template_name='landing.html'), name='landing'),
path("about/", views.about_page),
path("ahp/", views.ahp_page),

]